<div>
<section class="order_details" >
        <div class="container-order" style="width:1400px;margin:0px auto;  align-items: center; height:200px;" >
            <h3 class="title_confirmation">Đặt Hàng Thành Công ! <a href="index.php?pg=profile-user"> Xem Đơn Hàng Tại Đây </a></h3>
        </div>
</section>
</div>