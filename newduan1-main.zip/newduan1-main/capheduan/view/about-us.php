<div class="all-the-text">
    <div class="we-all-text">
    <div class="text-we">
        <div class="text-title"><h2>VỀ CHÚNG TÔI</h2></div>
    </div>
    <div class="text-we-2">
        <p>Chào bạn quý mến, </p><br>
        <p>Trước tiên chúng tôi chân thành cảm ơn bạn đã ghé thăm The boys Coffee</p><br>
        <p>Chúng tôi là một đội ngũ trẻ với tình yêu cà phê vô cùng lớn, dám nghĩ lớn và không ngại khác biệt. Quan trọng nhất: chúng tôi tin rằng mỗi tách cà phê có thể là một trải nghiệm đặc biệt và có sức mạnh để biến một ngày của bạn thành một ngày tuyệt vời. </p>
        <p>Đó là lý do tại sao sứ mệnh của chúng tôi là mang đến cho bạn tất cả các dụng cụ pha cà phê tốt nhất với thiết kế độc đáo, tính năng thông minh và được lựa chọn kỹ càng để bạn có thể thưởng thức ly cà phê ngon của mình mọi lúc, mọi nơi.</p>
    </div>
</div>
</div>